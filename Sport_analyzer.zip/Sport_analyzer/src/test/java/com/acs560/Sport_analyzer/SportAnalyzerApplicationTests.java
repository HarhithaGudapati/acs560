package com.acs560.Sport_analyzer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SportAnalyzerApplicationTests {

	@Test
	void contextLoads() {
	}

}
